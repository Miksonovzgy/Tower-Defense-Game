package LevelDescription

case class Wave(numWave : Int, numRegs : Int, numHeavies : Int, numBosses : Int) {
}
