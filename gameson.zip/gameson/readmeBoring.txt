How to run it

Linux
- In order to build the project go to root folder and run ./gradlew , after that it should be ready to run
- To run it either Run the Menu from the IDE or try with ./gradlew run ,but personally I was not able to do it since I am using Ubuntu and it seemingly has some issues with running processing sketches

Windows
- To build, run gradlew , after that the project is built
- To run the project You can, again, either Run the Menu from the IDE or run gradlew run from the command line (which will work this time actually)


What is it?
Shape Warfare 2: Square Assault is a Tower Defense Game. The Player is put in the position of Your squad's only remaining Rounded Square, 
after a skirmish. As Your last stand, You valiantly defend the passage to Your former outpost as Your wounded comrades are retreating.
 The assault of Rectangles and Circle-o Squares was devastating, but You cannot let them get to Your brothers, before they retreat.

What it comprises of?
4 original and personally crafted maps, representing the path to Your former base
3 different types of Enemies representing Regular Circle-o Squares; Heavier Rectangles and Devastating 4-Eyed Bosses
4 levels of difficulty with 10 waves each
A working menu Allowing You to choose the Difficulty level; Read the Instruction or Start the game

Video Demo
https://video.vu.nl/media/Shapes_Warfare_720.mp4/1_7bsyx0uz