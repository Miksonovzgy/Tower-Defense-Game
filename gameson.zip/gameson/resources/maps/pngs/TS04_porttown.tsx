<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TS04_porttown" tilewidth="20" tileheight="20" tilecount="160" columns="16">
 <image source="D:/Tiled/TS04_porttown.bmp" width="320" height="200"/>
</tileset>
